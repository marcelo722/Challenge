# Loadsmart SecEng challenge

This is a take-home project for the Security Engineer position @ Loadsmart. Thank you for considering us. We hope you enjoy it!

## Overview

This project is a REST API application with an admin interface. It's written in Python (tested with 3.8.3) using Django and DRF (Django REST Framework). The application uses a SQLite backend database. 

The API has one endpoint `/api/users`.

The admin interface can be found at `/admin`.

## Security constraints

The security premise are:

1. Anyone (even unauthenticated) can create a new user
1. Personal information (address, city, ZIP, password) can only be seen by own user and admins
1. No one should be able to create an admin user or edit other users details, except for admins

## Task

Developers said they're ready to send this to production.

Your task here is to give feedback for them about this project security. You can list anything that you would change or recommend the developers team to change.

You don't need to change it, but feel free to do so. 

After your recommendations, developers will work to fix any issues that possibly arise.

You can check below instructions on installing and interacting with the API.

## Installation

Creating a virtualenv:

```
python -m venv venv
source venv/bin/activate
```

Installing required libraries:

```
pip install -r requirements.txt
```

Setting up database:

```
cd vulnapi
python manage.py migrate
```

Creating an admin user:

```
python manage.py createsuperuser
```

Running the server:

```
python manage.py runserver
```

You can now go to http://localhost:8000


## Interacting with API

On the examples shown below we're using [HTTPie](https://httpie.org/) to interact with the API.

Creating an user:

```
http post http://localhost:8000/api/users/ username=sholmes password=SecretPass email=a@b.com profile:='{"address": "221B Baker St", "city": "London", "zip": 12345}'
```

Authenticate an user:

```
http post http://localhost:8000/api/token/ username=sholmes password=SecretPass
```

Make an authenticated request:

```
http get http://localhost:8000/api/ "Authorization: Token 57c787af98bb37393c97e60e58354e20bd2065c7"
```

Access the admin interface:

http://localhost:8000/admin

List users (admins only):

```
http get http://localhost:8000/api/users "Authorization: Token 57c787af98bb37393c97e60e58354e20bd2065c7"
```

That's it.

Please send us a report with your findings and recommendations. If there's no vulnerability in the code, may some configurations be changed in order to ensure we're using best practices.

Good luck!